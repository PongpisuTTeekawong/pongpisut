<?php
session_start();
$IsConfrimActionLocal  = $_POST['checkedValue'];
if ($IsConfrimActionLocal == "true") {
    $_SESSION["AjaxFilterVerified"] = 1;
} elseif ($IsConfrimActionLocal == "false") {
    $_SESSION["AjaxFilterVerified"] = 0;
}
    echo $_SESSION["AjaxFilterVerified"];
