<html lang="en">

<head>
  <title>ระบบอินเตอร์เน็ตวิทยาลัยการอาชีพปัว</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--===============================================================================================-->
  <link rel="icon" type="image/png" href="images/icons/favicon.ico" />
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/utilLogin.css">
  <link rel="stylesheet" type="text/css" href="css/mainLogin.css">
  <!--===============================================================================================-->
  <script type="text/javascript" src="js/sweetalert.min.js"></script>
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
</head>


<body>
  <script>
  </script>
  <?php
error_reporting(0);

if ((isset($_SESSION['user_id']))) {
    header("Location:AdminManager.php");
}
   ?>



  <script>
  const toast = swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    animation: false,
    customClass: 'animated bounceInRight'
  });

  toast({
    type: 'warning',
    title: 'คำเตือน หน้านี้มีไว้สำหรับผู้ดูแลเท่านั้น'
  })
  </script>

  <div class="limiter">
    <div class="container-login100">
      <div class="wrap-login100">
        <div class="login100-pic">
          <img src="images/AdminPage.png" alt="IMG" width="auto" height="auto"></img>
          <br></br>
          <br></br>
          <p style="font-size:22.5px; text-align: center; color: 666666;">ระบบจัดการระบบอินเตอร์เน็ตของโรงเรียนเมืองยมวิทยาคาร</p>
        </div>
        <form class="login100-form validate-form" method="post" action="AdminManager.php">
          <span class="login100-form-title">
						<p style="font-size:22.5px;">ระบบจัดการอินเตอร์เน็ต</p>
						<p style="font-size:22.5px;"></p>
					</span>

          <div class="wrap-input100 validate-input" data-validate="กรุณาใส่ชื่อผู้ใช้งาน">
            <input class="input100" type="text" name="Admin_Username" placeholder="ชื่อผู้ใช้">
            <span class="focus-input100"></span>
            <span class="symbol-input100">
							<i class="fa fa-user-circle" aria-hidden="true"></i>
						</span>
          </div>

          <div class="wrap-input100 validate-input" data-validate="กรุณาใส่ชื่อผู้ใช้งาน">
            <input class="input100" type="password" name="Admin_Password" placeholder="รหัสผ่าน">
            <span class="focus-input100"></span>
            <span class="symbol-input100">
							<i class="fa fa-user-circle" aria-hidden="true"></i>
						</span>
          </div>
          <div class="container-login100-form-btn">
            <button class="login100-form-btn">ลงชื่อเข้าใช้</button>
          </div>

          <div class="text-center p-t-12">
            <span class="txt1">
								<hr>
						จัดทำโดย<br>
            นายเมธี  ตนะทิพย์<br>
            นายกษินนท์  วัดบุณเลี้ยง<br>
						</hr>
						<hr>
						(เทคโนโลยีสารสนเทศ)
					</hr>
						</span>
          </div>
        </form>
      </div>
    </div>
  </div>
</body>
</html>
