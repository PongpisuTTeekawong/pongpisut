<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
      <script type="text/javascript" src="js/sweetalert.min.js"></script>
  </head>
  <script>
  //ฟังชั่นเตือนให้กรอกข้อมูลก่อนถ้าเข้าผ่าน URL โดยตรง


  function Notlogin() {
    swal({
      title: 'ผิดพลาด',
      text: 'กรุณาเข้าสู่ระบบก่อน',
      timer: 3000,
      showConfirmButton: false,
      allowOutsideClick: false,
      allowEscapeKey: false,
      type: 'error',
    }).then((result) => {
      if (
        result.dismiss === swal.DismissReason.timer
      ) {
        // ทำหลังจากเวลาหมด
        window.location = "./";
      }
    })
  };

  function RefillData() {
    swal({
      title: 'ผิดพลาด',
      text: 'กรุณากรอกข้อมูลก่อน',
      timer: 3000,
      showConfirmButton: false,
      allowOutsideClick: false,
      allowEscapeKey: false,
      type: 'error',
    }).then((result) => {
      if (
        result.dismiss === swal.DismissReason.timer
      ) {
        // ทำหลังจากเวลาหมด
        window.location = "./";
      }
    })
  };



  function WelcomeToSystem()
  {
    const toast = swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,

});

toast({
  type: 'success',
  title: 'ยินดีต้อนรับสู่ระบบจัดการ'
})

  };


  function NotFounData() {
    swal({
      title: 'ไม่พบข้อมูล',
      text: 'กรุณาลองใหม่อีกครั้ง',
      timer: 3000,
      allowEscapeKey: false,
      showConfirmButton: false,
      allowOutsideClick: false,
      type: 'error',
    }).then((result) => {
      if (
        result.dismiss === swal.DismissReason.timer
      ) {
        // ทำหลังจากเวลาหมด
        window.location = "./";
      }
    })
  };
        document.getElementById("LogoutAdmin").onclick = LogoutPHP()
</script>

  <body>

  </body>
</html>

<?php


require '../ConnectToService.php';

error_reporting(0);

session_start();

if (!isset($_SESSION['Logout'])) {
    echo '<script>Notlogin()</script>';
} else {
    if (!isset($_SESSION['LoggedIn'])) {
        //ถ้าหาก isset มีค่าแล้ว
        //ถ้ามี !isset แสดงว่า "ถ้ายังไม่มี"
        $_SESSION['AdminSS_User']      = $_POST["Admin_Username"];
        $_SESSION['AdminSS_PW']        = $_POST["Admin_Password"];
        $_SESSION['AdminSS_Encrypted'] = md5($_POST["Admin_Password"]);
    }
    $AdminUser   = $_SESSION['AdminSS_User'];
    $AdminPW     = $_SESSION['AdminSS_PW'];
    $EncryptedPW = $_SESSION['AdminSS_Encrypted'];

    if ($_SESSION['AdminSS_User'] == null or $_SESSION['AdminSS_PW'] == null) {
        echo '<script>RefillData()</script>';
    } else {
        $sql    = "SELECT * FROM `Administrator_info` WHERE `AdminUsername` LIKE '$AdminUser' AND `AdminPassword` LIKE '$EncryptedPW'";
        $result = $conn->query($sql);


        if ($result->num_rows > 0) {
            //เงื่อนไขถ้ามี
            $sql2                  = "SELECT * FROM `student_info_table` ORDER BY `Password` DESC ";
            $result2               = $conn->query($sql2);
            $_SESSION['LoggedIn']  = true;
            $_SESSION['IsLogedIn'] = true;
            echo '<script>WelcomeToSystem()</script>';
        } else {
            //เงื่อนไขถ้าไม่มี
            echo '<script>NotFounData()</script>';
            echo "Fuck You";
        }
    }
}











?>
