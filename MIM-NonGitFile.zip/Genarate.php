<?php

/***************************
  Sample using a PHP array
****************************/

$FirstName_Var     =    "เมธี";
$LastName_Var      =    "ตนะทิพย์";
$Identify_Var      =    "1550600106431";
$Email_Var         =    "censor@gmail.com";
$BirthdayDay       =    "24/06/2000";
$PhoneNumber_Var   =    "0987630297";
$Course_Var        =    "1";
$StudentYear_Var   =    "3";
$ClassNumber_Var   =    "1";
$Department_Var    =    "4";
$JoinYear          =    "2543";
$UsernameGenarate  =    "5910401009";
$PasswordGenarate  =    "24062543";
$DepartmentName    =    "คอมพิวเตอร์";

require('fpdm.php');


$debugingPrint = false ;

if ($debugingPrint) {
    $fields = array(
        'Course_1'   			  			=> ' ',
        'Course_2'    						=> ' ',
        'FirstnameTop' 			    	=> 'เมธี',
        'LastnameTop'  		 			  => 'ตนะทิพย์',
        'Department'  		 			  => 'คอมพิวเตอร์',
        'FirstnameBot' 	   			  => 'เมธี',
        'LastnameBot' 	   			  => 'ตนะทิพย์',
        'Email'   				 			  => 'censor31337@gmail.com',
        '1_ID'    								=> '1',
        '2_ID'    								=> '5',
        '3_ID'   					 			  => '5',
        '4_ID'   					 			  => '0',
        '5_ID'   					  			=> '6',
        '6_ID'  					 			  => '0',
        '7_ID'  					 		 	  => '0',
        '8_ID'  					 			  => '1',
        '9_ID'  					  			=> '0',
        '10_ID'    								=> '6',
        '11_ID'    								=> '4',
        '12_ID'  					  			=> '3',
        '13_ID'    		 						=> '1',
        'StudentYears'   	  			=> '3',
        'Course_1'   			  			=> 'X',
        '1_BD'  					 			  => '2',
        '2_BD'   					  			=> '4',
        '3_BD'    								=> '0',
        '4_BD'    								=> '6',
        '5_BD'    								=> '2',
        '6_BD'    								=> '5',
        '7_BD'    								=> '4',
        '8_BD'    								=> '3',
        'StudentRoom'    					=> '1',
        'Course_2'    						=> ' ',
        'PhoneNumber'    					=> '0987630297',
        'GenaratedUsernameTop'    => '5910401431',
        'GenaratedPasswordTop'    => '24062543',
        'GenaratedUsername'    		=> '5910401431',
        'GenaratedPassword'    		=> '24062543'
);
} else {
    $BirthdayDay = explode('/', $BirthdayDay);
    $Date_Var          =    $BirthdayDay[0];
    $Month_Var         =    $BirthdayDay[1];
    $Years_Var         =    $BirthdayDay[2];
    $Years_Var         =    $Years_Var+543;

    $Identify_Var_Split = str_split($Identify_Var, 1);
    $NewArray = array();
    foreach ($Identify_Var_Split as &$value) {
        array_push($NewArray, $value);
    }

    $SumAllDate = $Date_Var . $Month_Var . $Years_Var;
    $BirthDay_Split = str_split($SumAllDate, 1);
    $BirthDayArray = array();

    foreach ($BirthDay_Split as &$value) {
        array_push($BirthDayArray, $value);
    }

    if ($Course_Var == 1) {
        $fields = array(
        'Course_1'   			  			=> 'X',
        'Course_2'    						=> ' ',
        'FirstnameTop' 			    	=> 'เมธี',
        'LastnameTop'  		 			  => 'ตนะทิพย์',
        'Department'  		 			  => 'คอมพิวเตอร์',
        'FirstnameBot' 	   			  => 'เมธี',
        'LastnameBot' 	   			  => 'ตนะทิพย์',
        'Email'   				 			  => 'censor31337@gmail.com',
        '1_ID'    								=> '1',
        '2_ID'    								=> '5',
        '3_ID'   					 			  => '5',
        '4_ID'   					 			  => '0',
        '5_ID'   					  			=> '6',
        '6_ID'  					 			  => '0',
        '7_ID'  					 		 	  => '0',
        '8_ID'  					 			  => '1',
        '9_ID'  					  			=> '0',
        '10_ID'    								=> '6',
        '11_ID'    								=> '4',
        '12_ID'  					  			=> '3',
        '13_ID'    		 						=> '1',
        'StudentYears'   	  			=> '3',
        'Course_1'   			  			=> 'X',
        '1_BD'  					 			  => '2',
        '2_BD'   					  			=> '4',
        '3_BD'    								=> '0',
        '4_BD'    								=> '6',
        '5_BD'    								=> '2',
        '6_BD'    								=> '5',
        '7_BD'    								=> '4',
        '8_BD'    								=> '3',
        'StudentRoom'    					=> '1',
        'Course_2'    						=> ' ',
        'PhoneNumber'    					=> '0987630297',
        'GenaratedUsernameTop'    => '5910401431',
        'GenaratedPasswordTop'    => '24062543',
        'GenaratedUsername'    		=> '5910401431',
        'GenaratedPassword'    		=> '24062543'

            );
    } elseif ($Course_Var == 2) {
        $fields = array(
          'Course_1'   			  			=> ' ',
          'Course_2'    						=> 'X',
        'FirstnameTop' 			    	=> 'เมธี',
        'LastnameTop'  		 			  => 'ตนะทิพย์',
        'Department'  		 			  => 'คอมพิวเตอร์',
        'FirstnameBot' 	   			  => 'เมธี',
        'LastnameBot' 	   			  => 'ตนะทิพย์',
        'Email'   				 			  => 'censor31337@gmail.com',
        '1_ID'    								=> '1',
        '2_ID'    								=> '5',
        '3_ID'   					 			  => '5',
        '4_ID'   					 			  => '0',
        '5_ID'   					  			=> '6',
        '6_ID'  					 			  => '0',
        '7_ID'  					 		 	  => '0',
        '8_ID'  					 			  => '1',
        '9_ID'  					  			=> '0',
        '10_ID'    								=> '6',
        '11_ID'    								=> '4',
        '12_ID'  					  			=> '3',
        '13_ID'    		 						=> '1',
        'StudentYears'   	  			=> '3',
        'Course_1'   			  			=> 'X',
        '1_BD'  					 			  => '2',
        '2_BD'   					  			=> '4',
        '3_BD'    								=> '0',
        '4_BD'    								=> '6',
        '5_BD'    								=> '2',
        '6_BD'    								=> '5',
        '7_BD'    								=> '4',
        '8_BD'    								=> '3',
        'StudentRoom'    					=> '1',
        'Course_2'    						=> ' ',
        'PhoneNumber'    					=> '0987630297',
        'GenaratedUsernameTop'    => '5910401431',
        'GenaratedPasswordTop'    => '24062543',
        'GenaratedUsername'    		=> '5910401431',
        'GenaratedPassword'    		=> '24062543'

            );
    }
}

$pdf = new FPDM('newGen.pdf');
$pdf->Load($fields, true); // second parameter: false if field values are in ISO-8859-1, true if UTF-8
$pdf->Merge();
$pdf->Output('D', "เอกสารลงทะเบียน.pdf");
