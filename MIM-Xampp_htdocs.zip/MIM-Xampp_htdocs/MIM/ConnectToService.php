 <?php
// ข้อมูลการเชื่อมต่อ Database หรือฐานข้อมูล
$servername = "mw.ac.th";
$username = "mwdotac_root";
$password = "0502!@#";
$dbname = "mwdotac_MIM";
// ข้อมูลการเชื่อมต่อ Mikrotik
$MikrotikIp = '10.0.3.82'; // Ip ของ Mikrotik
$MikrotikAdminUsername = 'admin'; // Username ของ Mikrotik
$MiktorikAdminPassword = '0502'; // รหัสผ่าน ของ Mikrotik
$debugMode = false;// เปิดโหมด Debug เพื่อแสดงข้อมูลหรือไม่

// สร้างการเชื่อมต่อไปยัง Database หรือฐานข้อมูล

$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn, "utf8");

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("เชื่อมต่อล้มเหลว : " . $conn->connect_error);
}

?>
