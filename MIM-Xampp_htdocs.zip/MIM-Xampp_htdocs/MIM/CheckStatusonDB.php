<?php
    ob_start();
    ob_end_clean();
    require 'ConnectToService.php';


      $identify_idAjax   = $_POST['identify_idAjax'];

      $QueryCheckingStatus = "SELECT * FROM `UserInformation` WHERE `ID_Passport` LIKE '$identify_idAjax'";
      $result = $conn->query($QueryCheckingStatus);


      if ($result->num_rows > 0) {
          // output data of each row
          while ($row = $result->fetch_assoc()) {
              $name                =  $row['name'];
              $lastname            =  $row['lastname'];
              $StatusResult        =  $row['IsVerified'];
              $GenaratedUser       =  $row['GeneratedUser'];
              $GenaratedPassword   =  $row['GeneratedPass'];

              if ($StatusResult) {
                  $AlertType = "Verified";
              } else {
                  $AlertType =  "NotVerified";
              }
          }
          $CheckStatusReturn = array($AlertType,$name,$lastname,$GenaratedUser,$GenaratedPassword);
      } else {
          $AlertType = "NotFoundData";
          $CheckStatusReturn = array($AlertType,null,null,null,null);
      }

      print json_encode($CheckStatusReturn);
