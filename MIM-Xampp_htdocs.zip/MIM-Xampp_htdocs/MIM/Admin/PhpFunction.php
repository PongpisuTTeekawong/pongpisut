<?php
header("Content-Type: application/json");
require '../ConnectToService.php';
require './routeros_api.class.php';

// ดึงข้อมูล ID_Passport
$ID_PassportLocal       = $_POST['ID_Passport'];
$IsConfrimActionLocal   = $_POST['IsConfrimAction'];


// ใส่ข้อมูล Mikrotik


$API = new RouterosAPI();
$API->debug = $debugMode;


    $SqlQueryInfomation = "SELECT * FROM `UserInformation` WHERE `ID_Passport` LIKE $ID_PassportLocal ";
    $SqlQueryInfomationResult = $conn->query($SqlQueryInfomation);


    if ($SqlQueryInfomationResult->num_rows > 0) {
        while ($row = $SqlQueryInfomationResult->fetch_assoc()) {
            if ($IsConfrimActionLocal == "Yes") {
                if ($API->connect($MikrotikIp, $MikrotikAdminUsername, $MiktorikAdminPassword)) {
                    $API->comm("/ip/hotspot/user/add", array(
                      "name"     => $row["GeneratedUser"],
                      "password" => $row["GeneratedPass"],
                      "profile" => "Student",
                      "disabled"  => "no",
                    ));
                    $API->disconnect();
                    //อัพเดตข้อมูลใน SQL
                    $UpdateSqlVerified = "UPDATE `UserInformation` SET `IsVerified` = '1' WHERE `UserInformation`.`ID_Passport` = '$ID_PassportLocal' ";
                    $conn->query($UpdateSqlVerified);
                    $isUpdatedMysqlAndMikrotik = true;
                } else {
                    $isUpdatedMysqlAndMikrotik = false;
                }
            } elseif ($IsConfrimActionLocal == "No") {
                $sqltoDelete = "DELETE FROM `UserInformation` WHERE `UserInformation`.`ID_Passport` = '$ID_PassportLocal'";
                if (mysqli_query($conn, $sqltoDelete)) {
                    echo "Record deleted successfully";
                } else {
                    echo "Error deleting record: " . mysqli_error($conn);
                }
            }
        }
    }
    print json_encode($isUpdatedMysqlAndMikrotik);
